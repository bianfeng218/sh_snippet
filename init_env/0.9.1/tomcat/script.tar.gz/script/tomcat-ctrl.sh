#!/bin/sh


if [ "$1" = "start" ] ; then
	/export/Domains/server1/bin/start.sh
elif [ "$1" = "stop" ] ; then
	/export/Domains/server1/bin/stop.sh
elif [ "$1" = "restart" ] ; then
	/export/Domians/server1/bin/start.sh
	sleep 5
	/export/Domains/server1/bin/stop.sh
fi
