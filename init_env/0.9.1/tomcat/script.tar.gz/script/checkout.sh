#!/bin/sh
echo '---set param and init---'
DOMAIN_NAME='server1'
INSTANCE_PATH='/export/Domains/'$SERVER_NAME'/'
SOURCE_PATH='/export/App/'$DOMAIN_NAME'/code/'
SVN_BRANCHES='http://svn1.360buy-develop.com/repos2/ka/vop/old-vop-api/trunk'

echo '---delete and check out codes---'
cd $SOURCE_PATH
rm -rf trunk
#svn co $SVN_BRANCHES --username wangyong --password wangyongwy
