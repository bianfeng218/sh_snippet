#!/bin/sh
tail -f /Domains/server1/logs/catalina.out
