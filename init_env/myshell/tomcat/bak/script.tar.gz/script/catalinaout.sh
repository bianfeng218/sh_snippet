#!/bin/sh
DOMAIN_HOME=server1

if [[ "$1" = "" ]];then
	echo "./catalinaout.sh instance"
	exit 0
fi
INSTANCE_NUMBER=$1
INSTANCE_COUNT=`ls $domain|wc -l`
if [[ $INSTANCE_NUMBER > $INSTANCE_COUNT || $INSTANCE_NUMBER<1 ]];then
	echo "实例编号不正确1-$INSTANCE_COUNT"
	exit 0
fi
tail -f $DOMAIN_HOME/server$INSTANCE_NUMBER/logs/catalina.out
