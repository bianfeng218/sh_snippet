#!/bin/sh
DOMAIN_HOME=server1

if [[ "$1" = "" || "$2" = "" ]];then
	echo "./tomcat-ctrl.sh start|stop|restart instanceid|all"
	echo "./tomcat-ctrl.sh start 1   or ./tomcat-ctrl stop all"
	exit 0
fi

INSTANCE_NUMBER=$2
INSTANCE_COUNT=`ls $DOMAIN_HOME|wc -l`

if [[ "$2" = "all" ]];then
  for (( i=1; i<=$INSTANCE_COUNT; i++ ))
  do
	if [ "$1" = "start" ] ; then
		$DOMAIN_HOME/server$i/bin/start.sh
	elif [ "$1" = "stop" ] ; then
		$DOMAIN_HOME/server$i/bin/stop.sh
	elif [ "$1" = "restart" ] ; then
		$DOMAIN_HOME/server$i/bin/stop.sh
		sleep 3
		$DOMAIN_HOME/server$i/bin/start.sh
	fi
  done
  exit 0
fi

if [[ $INSTANCE_NUMBER > $INSTANCE_COUNT || $INSTANCE_NUMBER<1 ]];then
	echo "实例编号不正确1-$INSTANCE_COUNT"
	exit 0
fi

if [ "$1" = "start" ] ; then
	$DOMAIN_HOME/server$INSTANCE_NUMBER/bin/start.sh
elif [ "$1" = "stop" ] ; then
	$DOMAIN_HOME/server$INSTANCE_NUMBER/bin/stop.sh
elif [ "$1" = "restart" ] ; then
	$DOMAIN_HOME/server$INSTANCE_NUMBER/bin/stop.sh
	sleep 3
	$DOMAIN_HOME/server$INSTANCE_NUMBER/bin/start.sh
fi
