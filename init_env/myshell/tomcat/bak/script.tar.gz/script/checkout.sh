#!/bin/sh
echo '---set param and init---'
DOMAIN_NAME=server1
SOURCE_PATH=/export/App/'$DOMAIN_NAME'/code/
SVN_BRANCHES=''

echo '---delete and check out codes---'
cd $SOURCE_PATH
rm -rf trunk
