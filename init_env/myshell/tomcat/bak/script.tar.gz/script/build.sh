#!/bin/sh
echo '---set param and init---'
DOMAIN_NAME=server1
SOURCE_PATH=/export/App/${DOMAIN_NAME}/code

echo '---update codes---'
./checkout.sh
echo '---build project---'
mvn clean package -Pdevelopment -DskipTests -U
if [ $? != 0 ]; then
    echo "error build"
    exit 1
fi

echo '---copy war and startup tomcat---自行修改'
#cp -f ./bop-web/target/bop-web.war $INSTANCE_PATH/bop-web.war

./tomcat_ctrl.sh restart all
